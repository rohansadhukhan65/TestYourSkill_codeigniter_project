<!DOCTYPE html>
<html>
<head>
	<title>Student Login</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css">
    <script type="text/javascript" src="<?php echo base_url();?>js/index.js"></script>
</head>

<body>
  <div class="hero" style="background-image: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)),url(<?php echo base_url()?>image/1.jpg); background-position:cover;">
  	<div class="form-box">
  		<div class="button-box">
  			<div id="btn"></div>
  			<button type="button" class="toogle" id="btn1" onclick="login()">Log In</button>
  			<button type="button" class="toogle" id="btn1"  onclick="register()">Register</button>
  		</div>
  	    <form id="login" action="studentlog" class="input-group" method="post" autocomplete="off">
  	    	<input type="email" name="email" class="input-field text-dark" placeholder="Enter email" required>
  	    	<input type="password" name="password" class="input-field text-dark" placeholder="Enter Password" required>
  	    	<input type="submit" name="submit" value="Login" class="submit-btn text-white">
  	    </form>
  	    
        <form id="register" action="student_register" class="input-group" method="post">
  	    	<input type="text" name="name" class="input-field text-dark" placeholder="Full name" required>
  	    	<input type="email" name="email" class="input-field text-dark" placeholder="Email Id" required>
  	    	<input type="password" name="pass" class="input-field text-dark" autocomplete="off" placeholder="Password" required>
            <input type="phone" name="phone" class="input-field text-dark" placeholder="Phone" required>
  	    	<input type="submit" name="submit" class="submit-btn text-white" value="Register">
  	    </form>
  	</div>
  </div>
    <script>
      var x=document.getElementById("login");
      var y=document.getElementById("register");
      var z=document.getElementById("btn");

      function register()
      {
      x.style.left="-400px";
      y.style.left="50px";
      z.style.left="110px";
      }

      function login()
      {
      x.style.left="50px";
      y.style.left="450px";
      z.style.left="0";
      }
    </script>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k"
        crossorigin="anonymous"></script>
</body>
</html>