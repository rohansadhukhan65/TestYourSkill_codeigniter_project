<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css">
    <script type="text/javascript" src="<?php echo base_url();?>js/index.js"></script>
</head>
<body style="background-image: url('<?php echo base_url(); ?>image/admin_home.jpg');background-size:cover;">
    
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand text-warning">Admin Panel</a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="admin_home">Home<span class="sr-only">(current)</span></a>
            </li> 
          </ul>
          <ul class="nav justify-content-end">
            <li>
            <a href="admin_logout">
            <button type="submit" class="btn btn-danger">Logout</button>
           </a>
            </li>
          </ul>
        </div>
      </nav>


      <div class="container">
        <div class="row ">
        <!-- <div class="col">
    <div class="my-3">
        <h1 class="center text-warning text-center mt-5 font-weight-bold">TestYourSkill</h1>
    </div>
    </div> -->
    <div class="col-sm-12">
    <div class="my-3">
        <h3 class="center text-center alert alert-danger mt-5 font-weight-bold">TestYourSkill</h3>
        <h1 id="admin_heading" class="center text-success text-center mt-5 font-weight-bold">Welcome to Admin Panel </h1>
    </div>
    </div>
    </div>
    </div>

    <div class="row mt-5 ml-5">
    <div class="col-sm-3">
    <a href="add_question" class="text-decoration-none text-dark">
      <div class="card border-dark" style="width: 18rem;">
        <img src="<?php echo base_url()?>image/add_qs.png" class="card-img-top" height="200vh" >
      <div class="card-body text-center">
       <h5 class="text-monospace font-weight-bold">>> Add Question</h5>
    </div>
      </div>
  </div>
  </a>
 
  <div class="col-sm-3">
    <a href="edit_paper" class="text-decoration-none text-dark">
      <div class="card border-info" style="width: 18rem;">
        <img src="<?php echo base_url()?>image/edit_qs.png" class="card-img-top" height="200vh">
      <div class="card-body text-center">
      <h5 class="tex-monospace font-weight-bold">>> Edit Question</h5>
    </div>
      </div>
  </div>
  </a>
  <div class="col-sm-3">
    <a href="student_details" class="text-decoration-none text-dark ">
      <div class="card border-success" style="width: 18rem;">
        <img src="<?php echo base_url()?>image/student.jpg" class="card-img-top" height="200vh" >
      <div class="card-body text-center">
       <h5 class="tex-monospace font-weight-bold">>> Student Details</h5>
    </div>
      </div>
  </div>
  </a>
  <div class="col-sm-3">
    <a href="result_details" class="text-decoration-none text-dark ">
      <div class="card border-warning" style="width: 18rem;">
        <img src="<?php echo base_url()?>image/result.png" class="card-img-top" height="200vh" >
      <div class="card-body text-center">
       <h5 class="tex-monospace font-weight-bold">>> Result</h5>
    </div>
      </div>
  </div>
  </a>
  </div>

  <div class="row ml-5  mt-5 mb-4">
  <div class="col-sm-3 offset-3">
    <a href="student_query" class="text-decoration-none text-dark">
      <div class="card border-warning " style="width: 18rem;">
        <img src="<?php echo base_url()?>image/contact.jpg" class="card-img-top" height="200vh">
      <div class="card-body text-center">
       <h5 class="tex-monospace font-weight-bold">>> Student Query</h5>
    </div>
      </div>
  </div>
  </a>

  <div class="col-sm-3">
    <a href="student_feedback" class="text-decoration-none text-dark ">
      <div class="card border-warning" style="width: 18rem;">
        <img src="<?php echo base_url()?>image/feedback1.png" class="card-img-top" height="200vh" >
      <div class="card-body text-center">
       <h5 class="tex-monospace font-weight-bold">>> Student Feedback</h5>
    </div>
      </div>
  </div>
  </a>
</div>

<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k"
        crossorigin="anonymous"></script>
</body>
</html>