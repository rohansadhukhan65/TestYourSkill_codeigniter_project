<?php
class Online_exam extends CI_Controller
{
    function __construct()
    {
        parent::__construct();  //default constructer
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('Exam_model');
    }


    // this is for home page
    function home()
    {
        $this->load->view('home');
    }

    
    // this for about page
    function about()
    {
        $this->load->view('about');
    }


    // this for contact page
    function contact()
    {
        $this->load->view('contact');
    }


    // this for feedback page
    function feedback()
    {
        $this->load->view('feedback');
    }


    // this for admin login page
    function adminlog()
    {
        $this->load->view('admin_login');
        if($this->input->post('submit'))
        {
            $admin_email=$this->input->post('email');
            $admin_pass=$this->input->post('pass');
            if($this->Exam_model->admin($admin_email,$admin_pass))
            {
                redirect('Online_exam/admin_home');
            }
            else
            {
            ?>
                <div class="alert alert-warning alert-dismissible fade show mt-2" role="alert">
                <strong>Error!</strong> Invalid email or password.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>    
              </div>
            <?php
            }
        }
    }



    // this  admin homne page that come after login
    function admin_home()
    {
        $this->load->view('admin_homepage');
    }



    // this for student login page
    function studentlog()
    {
        $this->load->view('student_login');
    }


    // this is a text menu page where we can see different kinds of test
    function test()
    {
        $this->load->view('testpage');
    }


    // this for general apptitude test which will show all topic of different subject of general apptitude test 
    function arithematic_aptitude()
    {
        $this->load->view('arithematic');
    }
    // this is a topic that above told
    function arithematic1()
    {
        $this->load->view('arithematic_page1'); // start exam page of that, below two  is same as it
    } 
    function arithematic2()
    {
        $this->load->view('arithematic_page2');
    } 
    function arithematic3()
    {
        $this->load->view('arithematic_page3');
    } 









    



    // this for data interpretation test which will show all topic of different subject of data interpretation  test 
    function data_interpretation()
    {
        $this->load->view('interpretation');
    } 

    // this is a topic that above told
    function data_interpretation1()
    {
        $this->load->view('interpretation_page1');  // start exam page of that, below two is same as it
    } 
    function data_interpretation2()
    {
        $this->load->view('interpretation_page2');
    } 
    function data_interpretation3()
    {
        $this->load->view('interpretation_page3');
    } 
    

    
     // this for online aptitude test which will show all topic of different subject of aptitude  test 
    function online_aptitude()
    {
        $this->load->view('aptitude');
    } 

    // this is a topic that above told
    function online_aptitude1()
    {
        $this->load->view('online_aptitude_page1');  // start exam page of that, below two is same as it
    } 
    function online_aptitude2()
    {
        $this->load->view('online_aptitude_page2');
    } 
    function online_aptitude3()
    {
        $this->load->view('online_aptitude_page3');
    } 









    
    // this for verval ability test which will show all topic of different subject of ability  test 
    function verbal_ability()
    {
        $this->load->view('verbal');
    }
    // this is a topic that above told
    function verbal_ability1()
     {
        $this->load->view('verbal_ability_page1');  // start exam page of that, below two is same as it
    } 
    function verbal_ability2()
    {
        $this->load->view('verbal_ability_page2');
    } 
    function verbal_ability3()
    {
        $this->load->view('verbal_ability_page3');
    } 




    // this for  reasoning test which will show all topic of different subject of reasoning  test 
    function logical_reasoning()
    {
        $this->load->view('logical');
    } 
    // this is a topic that above told
    function reasoning1()
     {
        $this->load->view('reasoning_page1');  // start exam page of that, below two is same as it
    } 
    function reasoning2()
    {
        $this->load->view('reasoning_page2');
    } 
    function reasoning3()
    {
        $this->load->view('reasoning_page3');
    } 





    // this for non verbal reasoning test which will show all topic of different subject of non verbal reasoning  test 
    function non_verbal_reasoning()
    {
        $this->load->view('nonverbal');
    }
    // this is a topic that above told
    function non_verbal_reasoning1()
     {
        $this->load->view('non_verbal_reasoning_page1');  // start exam page of that, below two is same as it
    } 
    function non_verbal_reasoning2()
    {
        $this->load->view('non_verbal_reasoning_page2');
    } 
    function non_verbal_reasoning3()
    {
        $this->load->view('non_verbal_reasoning_page3');
    } 






    // this for non general knowledge test which will show all topic of different subject of general knowledge  test 
    function basic_general_knowledge()
    {
        $this->load->view('generalknowledge');
    }
     // this is a topic that above told
     function general_knowledge1()
     {
        $this->load->view('general_knowledge_page1');  // start exam page of that, below two is same as it
    } 
    function general_knowledge2()
    {
        $this->load->view('general_knowledge_page2');
    } 
    function general_knowledge3()
    {
        $this->load->view('general_knowledge_page3');
    } 







    // this for non general science test which will show all topic of different subject of general science  test
    function general_science()
    {
        $this->load->view('generalscience');
    } 
    // this is a topic that above told
    function general_science1()
    {
       $this->load->view('general_science_page1');  // start exam page of that, below two is same as it
   } 
   function general_science2()
   {
       $this->load->view('general_science_page2');
   } 
   function general_science3()
   {
       $this->load->view('general_science_page3');
   } 






   // this for non general science test which will show all topic of different subject of general science  test
    function current_affairs()
    {
        $this->load->view('currentaffairs');
    }
     // this is a topic that above told
     function current_affairs1()
     {
        $this->load->view('current_affairs_page1');  // start exam page of that, below two is same as it
    } 
    function current_affairs2()
    {
        $this->load->view('current_affairs_page2');
    } 
    function current_affairs3()
    {
        $this->load->view('current_affairs_page3');
    } 






    //this for java test.there is 3 part and when click on that exam page open directly
    function java_mcq_test1()
    {
        $this->load->view('mcqset1');
    }
    function java_mcq_test2()
    {
        $this->load->view('mcqset2');
    }
    function java_mcq_test3()
    {
        $this->load->view('mcqset3');
    }
    



    //this for c test.there is 3 part and when click on that exam page open directly
    function c_mcq_test1()
    {
        $this->load->view('cmcqset1');
    }
    function c_mcq_test2()
    {
        $this->load->view('cmcqset2');
    }
    function c_mcq_test3()
    {
        $this->load->view('cmcqset3');
    }




    //this for php test.there is 3 part and when click on that exam page open directly
    function php_mcq_test1()
    {
        $this->load->view('phpmcqset1');
    }
    function php_mcq_test2()
    {
        $this->load->view('phpmcqset2');
    }
    function php_mcq_test3()
    {
        $this->load->view('phpmcqset3');
    }



    //here admin can add question
    function add_question()
    {
        $this->load->view('add_question_page');
    }

    //here admin can edit question
    function edit_paper()
    {
        $this->load->view('edit_paper_page');
    }

    //here admin can see student details
    function student_details()
    {
        $this->load->view('student_details_page');
    }

    //here admin can see student results
    function result_details()
    {
        $this->load->view('result_details_page');
    }

}
?>