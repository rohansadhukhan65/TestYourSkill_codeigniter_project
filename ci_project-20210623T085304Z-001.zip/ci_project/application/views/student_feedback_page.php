<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Feedback</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link rel="stylesheet" href="{% static 'css/style.css' %}">
</head>
<script>
    //this is written so that back button of browser could not work, this work only when we go to another page or link from this page
    window.history.forward();
    function noback() {
        window.history.forward();
    }
</script>

<body style="background-image: url('<?php echo base_url(); ?>image/start.jpg');background-size:cover;">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand text-warning">TestYourSkill</a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item">
                <a class="nav-link" href="admin_home">Home<span class="sr-only">(current)</span></a>
              </li>
          </ul>
          <form action="student_feedback_search" method="POST" class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" name="search" placeholder="name" aria-label="Search">
            <input class="btn btn-outline-success my-2 my-sm-0" type="submit" name="submit" value="Search">
          </form>
        </div>
      </nav>
    <div class="container-fluid">
        <h1 class="text-center mt-3 alert alert-primary">Feedback Of The Students</h1>
        <hr class="bg-info">
        <div >
            <?php 
            if($std_feedback)
            {
            ?>
            <table class="table table-hover">
                <thead style="background-color:tan;">
                    <tr>
                        <th scope="col" class="bg">Sl. No.</th>
                        <th scope="col" class="bg">Name</th>
                        <th scope="col" class="bg">Email</th>
                        <th scope="col" class="bg">Feedback</th>
                        <th scope="col" class="bg">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i=1;
                    foreach($std_feedback as $row)
                    {
                    ?>
                    <tr>
                        <th scope="row"><?php echo $i;$i+=1; ?></th>
                        <th><?php echo $row->name?></th>
                        <td><?php echo $row->email?></td>
                        <td><?php echo $row->experience?></td>
                         <th><a href="delete_student_feedback?id=<?php echo $row->feed_id ?>" type="button" class="btn-danger btn-sm"
                                style="text-decoration: none;">Delete</a>
                        </th> 
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
            <?php } 
            else{
            ?>
           <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                <strong>No records found.</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>    
            </div>
            <div class="text-center">
            <a href="student_feedback" class="btn btn-warning">Back</a>
            </div>
            <?php
            }
            ?>
        </div>
        <hr class="mt-5 bg-dark"><hr class="bg-dark">
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k"
        crossorigin="anonymous"></script>
</body>

</html>