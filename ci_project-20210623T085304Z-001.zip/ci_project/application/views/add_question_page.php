<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Question</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css">
    <script type="text/javascript" src="<?php echo base_url();?>js/index.js"></script>
</head>
<body style="background-image: url('<?php echo base_url(); ?>image/3.jpg');background-size:cover;">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand text-warning">TestYourSkill</a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item">
                <a class="nav-link" href="admin_home">Home<span class="sr-only">(current)</span></a>
              </li>
          </ul>
        </div>
      </nav>
<div class="container">
<h3 class=" alert alert-danger text-center mt-5">ADD Question</h3>
<div class="row">
    <div class="col-sm-6 offset-3">
        <form action="add_question" method="POST">
            <div class="form-group">
            <h3 class="mx-1">Topic</h3>
              <select class="form-select alert alert-success" name="topic" aria-label="Default select example">
                <<option selected disabled>Choose</option>
                <option value="Problem Set1">Problem Set1</option>
                <option value="Problem Set2">Problem Set2</option>
                <option value="Problem Set3">Problem Set3</option>
                <option value="Time and Distance">Time and Distance</option>
                <option value="Time and Work">Time and Work</option>
                <option value="Problems on Ages">Problems on Ages</option>
                <option value="Problems on Trains">Problems on Trains</option>
                <option value="Height and Distance">Height and Distance</option>
                <option value="Simple Interest">Simple Interest</option>
                <option value="Spotting Errors">Spotting Errors</option>
                <option value="Antonyms">Antonyms</option>
                <option value="Spelling">Spelling</option>
                <option value="Number Series">Number Series</option>
                <option value="Verbal Classification">Verbal Classification</option>
                <option value="Logical Games">Logical Games</option>
                <option value="Series">Series</option>
                <option value="History">History</option>
                <option value="Biology">Biology</option>
                <option value="Countries and Sports">Countries and Sports</option>
                <option value="Neighbouring Country">Neighbouring Country</option>
                <option value="Capital and Currencies">Capital and Currencies</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Computer">Computer</option>
                <option value="Current Affairs 2019">Current Affairs 2019</option>
                <option value="Current Affairs 2020">Current Affairs 2020</option>
                <option value="Current Affairs 2021">Current Affairs 2021</option>
                <option value="Java Mcq Tets1">Java Mcq Test1</option>
                <option value="Java Mcq Tets2">Java Mcq Test2</option>
                <option value="Java Mcq Tets3">Java Mcq Test3</option>
                <option value="C Mcq Test1">C Mcq Test1</option>
                <option value="C Mcq Test2">C Mcq Test2</option>
                <option value="C Mcq Test3">C Mcq Test3</option>
                <option value="Php Mcq Test1">Php Mcq Test1</option>
                <option value="Php Mcq Test2">Php Mcq Test2</option>
                <option value="Php Mcq Test3">Php Mcq Test3</option>
              </select>
            </div>
             <h4 class="mx-1">Add Question</h4>
                  <div class="form-group">
                  <textarea class="form-control" name="ques" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>
                  

                  <div class="row">
                  <div class="col-lg-3">
                  <div class="form-group">
                  <h4 class="mx-1">Option A </h4>
                  </div>
                  </div>
                  <div class="col-lg-9">
                  <div class="form-group">
                  <input type="text" name="op1" class="form-control" id="addstudent" required autocomplete="off" aria-describedby="emailHelp">
                  </div>
                  </div>

                  <div class="col-lg-3">
                  <div class="form-group">
                  <h4 class="mx-1">Option B </h4>
                  </div>
                  </div>
                  <div class="col-lg-9">
                  <div class="form-group">
                  <input type="text" name="op2" class="form-control" id="addstudent" required autocomplete="off" aria-describedby="emailHelp">
                  </div>
                  </div>

                  <div class="col-lg-3">
                  <div class="form-group">
                  <h4 class="mx-1">Option C</h4>
                  </div>
                  </div>
                  <div class="col-lg-9">
                  <div class="form-group">
                  <input type="text" name="op3" class="form-control" id="addstudent" required autocomplete="off" aria-describedby="emailHelp">
                  </div>
                  </div>

                  <div class="col-lg-3">
                  <div class="form-group">
                  <h4 class="mx-1">Option D </h4>
                  </div>
                  </div>
                  <div class="col-lg-9">
                  <div class="form-group">
                  <input type="text" name="op4" class="form-control" id="addstudent" required autocomplete="off" aria-describedby="emailHelp">
                  </div>
                  </div>

                  <div class="col-lg-3">
                  <div class="form-group">
                  <h4 class="mx-1">Answer</h4>
                  </div>
                  </div>
                  <div class="col-lg-9">
                  <div class="form-group">
                  <input type="text" name="ans" class="form-control" id="addstudent" required autocomplete="off" aria-describedby="emailHelp">
                  <span class="text-primary">Choose the right option number or in digit like 1/2/3/4</span>
                  </div>
                  </div>


                  </div>
                  <div class="row text-center">
                    <div class="col-sm-3 ml-5">
                    <input type="submit" name="submit" value="Add" id="addbtn3" class="btn btn-outline-success mt-3 mb-3">
                    </div>
                    <div class="col-sm-5">
                    <a href="admin_home" class="text-center btn btn-warning rounded mt-3 mb-3">Cancel</a>
                    </div>
                    </div>
                </form>
            </div>
    </div>
</div>

           


<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k"
        crossorigin="anonymous"></script>
</body>
</html>